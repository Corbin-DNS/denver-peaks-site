Denver Peaks — GitHub Pages Package

How to publish:
1) Create a public repo (e.g., denver-peaks-site) and upload this whole folder.
2) Repo Settings → Pages → Source: Deploy from a branch, Branch: main /root → Save.
3) Your site will be at: https://YOUR-USERNAME.github.io/REPO-NAME/

Edit these files:
- index.html (content, schedule, pricing, roster)
- images/logo.png (header logo)
- images/denver-peaks-schedule.png (poster image)
- images/seating-map.png (placeholder seating chart)
- images/video-poster.jpg (placeholder for video)
- docs/Denver-Peaks-Sponsorship.pdf (optional deck placeholder)
